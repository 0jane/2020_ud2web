<?php
	$servername = "localhost";
	$username = "school";
	$password = "abc123";
	$db="school";
	$conn = mysqli_connect($servername, $username, $password,$db);
?>